export class Level {
  constructor(public name: string, public levelNumber: number) {}
}
