export class Category {
  constructor(public id: string, public title: string) {}
}
