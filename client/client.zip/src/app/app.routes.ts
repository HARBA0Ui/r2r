import { Routes } from '@angular/router';
import { HomePageComponent } from './components/home-page/home-page.component';
import { ProductPageComponent } from './components/product-page/product-page.component';
import { SignupformComponent } from './components/signupform/signupform.component';
import { LoginformComponent } from './components/loginform/loginform.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SearchPageComponent } from './components/search-page/search-page.component';
import { CreateProductComponent } from './components/create-product/create-product.component';
import { MainDashboardComponent } from './components/main-dashboard/main-dashboard.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { authGuard } from './auth.guard';
import { loginGuard } from './login.guard';
import { ProductsComponent } from './products/products.component';

export const routes: Routes = [
  {
    path: '',
    title: 'Homepage',
    component: HomePageComponent, // Default route '/'
  },
  {
    path: 'product/:id',
    title: 'Product Page',
    component: ProductPageComponent,
  },
  {
    path: 'register',
    title: 'signup form',
    component: SignupformComponent,
    canActivate: [loginGuard]
  },
  {
    path: 'login',
    title: 'login form',
    component: LoginformComponent,
    canActivate: [loginGuard]
  },
  {
    path: 'dashboard',
    title: 'dashboard form',
    component: DashboardComponent,
    canActivate: [authGuard],
    children: [
      { path: '', title: 'main dashboard', component: MainDashboardComponent },
      { path: 'create', title: 'new product', component: CreateProductComponent },
      { path: 'update/:id', title: 'update product', component: UpdateProductComponent, },
    ],
  },
  {
    path: 'search/:label',
    title: 'search page',
    component: SearchPageComponent,
  },
  {
    path: 'products',
    title: 'products',
    component: ProductsComponent,
    children: [
      {
        path: '/',
        title: 'all products',
        component: SearchPageComponent,
      },
      {
        path: '/:gender',
        title: 'products by gender',
        component: SearchPageComponent,
      },
      {
        path: '/:category',
        title: 'products by category',
        component: SearchPageComponent,
      },
    ]
  },
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full', // Redirect unknown paths to the homepage
  },
];
