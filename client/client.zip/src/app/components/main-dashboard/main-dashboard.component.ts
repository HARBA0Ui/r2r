import { Component, OnInit, inject } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { Product } from '../../classes/product';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-main-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './main-dashboard.component.html',
  styleUrls: ['./main-dashboard.component.css'],
})
export class MainDashboardComponent implements OnInit {
  products: Product[] = []; // Define a property to hold the products
  productService = inject(ProductService); // Use inject() to inject the service directly

  ngOnInit(): void {
    // Call the getAllProducts method when the component is initialized
    this.productService.getAllProducts().subscribe(
      (products: Product[]) => {
        // this.products = products; // Store the fetched products in the component property
        this.products = products;
        console.log(products);
      },
      (error) => {
        console.error('Error fetching products:', error);
      }
    );
  }
}
