import { Component, inject } from '@angular/core';
import { Product } from '../../classes/product';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../../services/product.service';
import { SpinnerComponent } from '../spinner/spinner.component';

@Component({
  selector: 'app-product-page',
  standalone: true,
  imports: [SpinnerComponent],
templateUrl: './product-page.component.html',
  styleUrl: './product-page.component.css',
})
export class ProductPageComponent {
  product!: Product; // Property to store the selected product
  productService: ProductService = inject(ProductService); // Inject the service functionally

  cityOptions: string[] = [
    'Ariana',
    'Beja',
    'Ben Arous',
    'Bizerte',
    'Gabes',
    'Gafsa',
    'Jendouba',
    'Kasserine',
    'Kef',
    'Mahdia',
    'Manouba',
    'Monastir',
    'Nabeul',
    'Sfax',
    'Sidi Bouzid',
    'Sousse',
    'Siliana',
    'Tataouine',
    'Tozeur',
    'Tunis',
    'Zaghouan',
    'Medenine',
    'Kebili',
    'Kairouan',
  ];

  constructor(
    private route: ActivatedRoute, // Inject ActivatedRoute to access route parameters
  ) {}

  ngOnInit(): void {
    // Get product ID from the route
    const productId = this.route.snapshot.paramMap.get('id');
    if (productId) {
      this.productService.getProductById(productId).subscribe(
        (product: Product) => {
          this.product = product; // Store the fetched product data
        },
        error => {
          console.error('Error fetching product:', error);
        }
      );
    }
  }

}
